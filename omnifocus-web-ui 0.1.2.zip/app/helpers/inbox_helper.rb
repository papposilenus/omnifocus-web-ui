module InboxHelper
end
